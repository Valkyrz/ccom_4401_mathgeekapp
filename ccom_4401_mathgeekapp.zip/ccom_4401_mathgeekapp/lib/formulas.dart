import 'package:flutter/material.dart';
import 'package:flutter_tex/flutter_tex.dart';

class FormulasPage extends MaterialPageRoute<Null> {
  FormulasPage() : super(builder: (BuildContext ctx) {
    FlutterTeX();
  });
}

class FlutterTeX extends StatefulWidget {
  @override
  _FlutterTeXState createState() => _FlutterTeXState();
}

//need to pull formulas from a file following this format ezclap

String firstFormula = r"""
  <p>
    $$x = {-b \pm \sqrt{b^2-4ac} \over 2a}$$
  </p>
  """;

class _FlutterTeXState extends State<FlutterTeX> {

  String teX = Uri.encodeFull(firstFormula);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Displaying a formula"),
        ),
        body: TeXView(
          teXHTML: teX,
        ),
      ),
    );
  }
}